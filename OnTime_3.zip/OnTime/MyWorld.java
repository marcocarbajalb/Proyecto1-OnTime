import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Carretera en la que se desarrolla el juego
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class MyWorld extends World
{
    //[[Definición de variables]]
    
    private Contador contadorEsquives, contadorDificultad; 
    //contadorEsquives: esta variable de tipo Contador será el contador para los esquives.
    //contadorDificultad:esta variable de tipo Contador será el contador para la dificultad.
    
    private int velocidad_carro, num_esquives, num_obstaculos;
    //velocidad_carro: este entero definirá la velocidad del carro.
    //num_esquives: este entero contendrá el número total de esquives que se han hecho en la dificultad actual.
    //num_obstaculos: este entero contendrá el número de obstáculos que se encuentran activos en la pantalla. 
    
    private final int num_esquives_dificultad = 6;
    //El número de esquives necesarios para aumentar la dificultad es de 6.
    
    private Carro carro;
    //Esta variable de tipo Carro será el carro que controlará el jugador. 
    
    private Ambiente a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, g1, g2, g3, g4;
    //Estas variables de tipo Ambiente serán la decoración de los laterales. 
    
    //[Constructor]
    public MyWorld()
    {    
       //Crear un nuevo mundo de 600 x 675 pixeles
       super(600,675,1);
       
       //Establecer que el número total de esquives inicie en 0.
       num_esquives = 0;
       //La velocidad inicial del carro (y, por tanto, de los obstáculos) es de 4.
       velocidad_carro = 4;
       
       //Crear los contadores de esquives y dificultad, así como el carro del jugador y toda la decoración.
       contadorEsquives = new Contador();
       contadorDificultad = new Contador();
       carro = new Carro(velocidad_carro);
       a1 = new Ambiente("Arbusto");
       a2 = new Ambiente("Arbusto");
       a3 = new Ambiente("Arbusto");
       a4 = new Ambiente("Arbusto");
       a5 = new Ambiente("Arbusto");
       a6 = new Ambiente("Arbusto");
       a7 = new Ambiente("Arbusto");
       a8 = new Ambiente("Arbusto");
       a9 = new Ambiente("Arbusto");
       a10 = new Ambiente("Arbusto");
       g1 = new Ambiente("Girasol");
       g2 = new Ambiente("Girasol");
       g3 = new Ambiente("Girasol");
       g4 = new Ambiente("Girasol");
       
       //La dificultad del juego debe iniciar en 1. 
       contadorDificultad.aumentar();
       
       //Posicionar los objetos (contadores y jugador) en la pantalla
       addObject(carro, 300, 570);
       addObject(contadorDificultad, 515, 40);
       addObject(contadorEsquives, 192, 40);
       
       //Decoración lado derecho
       addObject(a1,562,108);
       addObject(g1,531,152);
       addObject(a2,543,237);
       addObject(a3,564,351);
       addObject(a4,558,470);
       addObject(g2,527,589);
       addObject(a5,564,621);
       //Decoración lado izquierdo
       addObject(a6,53,108);
       addObject(g3,71,197);
       addObject(a7,37,234);
       addObject(a8,45,349);
       addObject(a9,55,477);
       addObject(g4,73,582);
       addObject(a10,38,621);
    }
    
    //[Método principal]
    public void act()
    {
        subir_dificultad();
        generador_de_obstaculos();
    }
    
    //[Métodos más relevantes]
    public void subir_dificultad()
    {
        if(num_esquives == num_esquives_dificultad){
            //Aumentar la velocidad del carro
            velocidad_carro = velocidad_carro + 1;
            carro.aumentar_velocidad();
            
            //Aumentar la dificultad
            contadorDificultad.aumentar();
            
            //Resetear la variable del número total de esquives que se han hecho en la dificultad actual
            num_esquives = 0;
        }
        /*Este método va a permitir aumentar la dificultad (que se manifiesta en la velocidad del carro)
        cuando el número de esquives en la dificultad actual llegue a 6.*/
    }
    
    public void generador_de_obstaculos()
    {
        if(num_obstaculos == 0)
        {
            String continuar;
            int carril = Greenfoot.getRandomNumber(3);
            //La variable carril tomará de forma aleatoria el valor de 0, 1 o 2.
            
            if(carril == 0) {
                addObject(new Obstaculo(velocidad_carro),185, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Obstaculo(velocidad_carro),300, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Obstaculo(velocidad_carro),415, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la derecha.
                }
            
            carril = carril + 1;
            carril = carril % 3;
            /*Al sumarle 1 al valor de carril y luego obtener el residuo que queda de dividir dentro
            de 3, se obtiene un entero diferente del anterior que también está entre 0 y 2.
            Si carril era 0, quedará 1. Si carril era 1, quedará 2. Si carril era 2, quedará 0.*/
            
            if(carril == 0) {
                addObject(new Obstaculo(velocidad_carro),185, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Obstaculo(velocidad_carro),300, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Obstaculo(velocidad_carro),415, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la derecha.
                }
            
            num_obstaculos = 2;
            
            /*Este método va a permitir generar dos obstáculos en dos carriles diferentes elegidos
            de forma aleatoria.*/
        }
    }
    
    //[Métodos o funciones secundarias]
    public void obstaculo_esquivado()
    {
        contadorEsquives.aumentar();
        num_esquives = num_esquives + 1;
        /*Este método va a permitir sumar 1 a la variable de los
        esquives en la dificultad actual.*/
    }
    
    public void disminuir_num_obstaculos()
    {
        num_obstaculos = num_obstaculos - 1;
        /*Este método va a permitir restar 1 a la variable del número de obstáculos que
        se encuentran activos en la pantalla.*/
    }  
}
