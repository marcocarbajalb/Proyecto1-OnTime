import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Obstáculo
 * 
 * @author Marco Carbajal y Carlos Aldana 
 * @version Greenfoot 3.7.1
 */
public class Obstaculo extends Actor
{
    //[Definición de variables]
    
    private int velocidad;
    //Este entero definirá la velocidad a la que se mueve el obstáculo.
    
    //[Constructor]
    public Obstaculo(int v)
    {
        velocidad = v;
        imagen();
    }
    
    //[Método principal]
    public void act()
    {
        movimiento();
        desaparecer();
    }
    
    //[Métodos más relevantes]
    public void imagen()
    {
        int tipo_de_obstaculo = Greenfoot.getRandomNumber(3);
        
        if(tipo_de_obstaculo == 0) {
                setImage(new GreenfootImage("Hoyo.png"));
                //Se le dará al obstáculo la imagen de un hoyo. 
                }
            else if(tipo_de_obstaculo == 1) {
                setImage(new GreenfootImage("Cono.png"));
                //Se le dará al obstáculo la imagen de un cono.
                }
            else {
                setImage(new GreenfootImage("Barrera.png"));
                //Se le dará al obstáculo la imagen de una barrera de tránsito.
                }
        /*Este método hace que aleatoriamente se le asigne una imagen a cada obstáculo
        creado, ya sea la imagen de un hoyo, de un cono, o de una barrera de tránsito.*/
    }
    public void movimiento()
    {
        setLocation(getX(), getY()+velocidad);
        /*Este método hace que el obstáculo se mueva hacia abajo, la velocidad determinará
        la cantidad de pixeles que avanzará el obstáculo al ejectuar el método.*/
    }
    public void desaparecer()
    {
      if (getY() >= getWorld().getHeight()-1)
        {
            MyWorld juego = (MyWorld) getWorld();
            juego.removeObject(this);
            juego.obstaculo_esquivado();
            juego.disminuir_num_obstaculos();
            Greenfoot.playSound("Esquive.wav");
        }
      /*Este método hace que, cuando el obstáculo llegue al límite inferior de la pantalla, se remueva
      dicho objeto. Además, contabiliza que el obstáculo fue esquivado y reproduce el sonido de esquive.*/
    }
}