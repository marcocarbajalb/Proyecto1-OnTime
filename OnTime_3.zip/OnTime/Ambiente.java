import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Decoración del ambiente. 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ambiente extends Actor
{
    //[Definición de variables]
    
    private String decoracion;
    //Esta variable de tipo String definirá el tipo de decoración que se mostrará. 
    
    //[Constructor]
    public Ambiente(String decoracion)
    {
        if (decoracion == "Arbusto"){
            setImage(new GreenfootImage("Arbusto.png"));
        }
        else{
            setImage(new GreenfootImage("Girasol.png"));
        }
        
        /*Este método hace que, si al crear un objeto de la clase Ambiente se le da como parámetro "Arbusto", este tendrá la
        imagen de un arbusto. Pero si se le da cualquier otro parámetro, tendrá la imagen de un girasol.*/
    }
}
