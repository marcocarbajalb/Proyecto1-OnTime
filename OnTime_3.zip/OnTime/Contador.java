import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Contador de esquives y de dificultad
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Contador extends Actor
{
    //[Definición de variables]
    
    public int conteo = 0;
    //Este entero será el valor del contador. 
    
    //[Constructor]
    public Contador()
    {
        setImage(new GreenfootImage(""+conteo+"", 30, Color.BLACK, Color.WHITE));
    }
    
    //[Método principal]
    public void act()
    {
        setImage(new GreenfootImage(""+conteo+"", 30, Color.BLACK, Color.WHITE));
        ganador();
    }
    
    //[Métodos más relevantes]
    public void aumentar(){
        conteo = conteo + 1;
    }
    public void ganador()
    {
        if (conteo == 30)
        {
        Greenfoot.setWorld(new Ganador());
        }
    }
}
