import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pantalla de inicio (o menú)
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Inicio extends World
{
    //[[Definición de variables]]
    
    public static final GreenfootSound musica_juego = new GreenfootSound("Musica_fondo.wav");
    //Esta variable contendrá la música que debe sonar de fondo en el juego. 
    
    private static Boton boton_inicio = new Boton("Boton inicio");
    //Esta variable será el botón para iniciar la partida. 
    
    //[Constructor]
    /**
     * Constructor for objects of class Inicio.
     * 
     */
    public Inicio()
    {    
        //Crear una pantalla para el menú de 600 x 675 pixeles
       super(600,675,1);
       
       //Posicionar el objeto (botón para iniciar la partida) en la pantalla
       addObject(boton_inicio, 300, 550);
    }
    
    //[Método principal]
    public void act()
    {
        musica();
        iniciarPartida();
    }
    
    //[Métodos más relevantes]
    public void iniciarPartida()
    {
        boolean click = Greenfoot.mouseClicked(boton_inicio);
        if (Greenfoot.isKeyDown("Space") || Greenfoot.isKeyDown("Enter") || click==true) {
            Greenfoot.setWorld(new MyWorld());
        }
        /*Este método va a permitir que, al presionar la barra espaciadora, enter o hacer click sobre el botón,
        se inicie una nueva partida.*/  
    }
    
    public void musica()
    {
        musica_juego.playLoop();
        /*Este método va a permitir que la música de fondo del juego se reproduzca en loop.*/ 
    }
}
