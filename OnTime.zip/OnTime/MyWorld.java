import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class MyWorld extends World
{
    //[[Definición de variables]]
    
    private Contador contadorEsquives; 
    //Esta variable de tipo Contador será el contador para los esquives.
    
    private Contador contadorDificultad;
    //Esta variable de tipo Contador será el contador para la dificultad.
    
    private int velocidad_carro;
    //Este entero definirá la velocidad del carro.
    
    private int num_esquives;
    //Este entero contendrá el número total de esquives que se han hecho en la dificultad actual.
    
    private final int num_esquives_dificultad = 6;
    //El número de esquives necesarios para aumentar la dificultad es de 6.
    
    private Carro carro;
    //Esta variable de tipo Carro será el carro que controlará el jugador. 
    
    private int num_obstaculos;
    //Este entero contendrá el número de obstáculos que se encuentran activos en la pantalla. 
    
    //[Constructor]
    public MyWorld()
    {    
       //Crear un nuevo mundo de 600 x 675 pixeles
       super(600,675,1);
       
       //Establecer que el número total de esquives inicie en 0.
       num_esquives = 0;
       //La velocidad inicial del carro es de 3.
       velocidad_carro = 3;
       
       //Crear los contadores de esquives y dificultad, así como el carro del jugador
       contadorEsquives = new Contador();
       contadorDificultad = new Contador();
       carro = new Carro(velocidad_carro);
       
       //La dificultad del juego debe iniciar en 1. 
       contadorDificultad.aumentar();
       
       //Posicionar los objetos (contadores y jugador) en la pantalla
       addObject(carro, 300, 585);
       addObject(contadorDificultad, 515, 40);
       addObject(contadorEsquives, 192, 40);
    }
    
    //[Método principal]
    public void act()
    {
        subir_dificultad();
        generador_de_obstaculos();
    }
    
    //[Métodos más relevantes]
    public void subir_dificultad()
    {
        if(num_esquives == num_esquives_dificultad){
            //Aumentar la velocidad del carro
            velocidad_carro = velocidad_carro + 1;
            carro.aumentar_velocidad();
            
            //Aumentar la dificultad
            contadorDificultad.aumentar();
            
            //Resetear la variable del número total de esquives que se han hecho en la dificultad actual
            num_esquives = 0;
        }
        /*Este método va a permitir aumentar la dificultad (que se manifiesta en la velocidad del carro)
        cuando el número de esquives en la dificultad actual llegue a 6.*/
    }
    
    public void generador_de_obstaculos()
    {
        if(num_obstaculos == 0)
        {
            String continuar;
            int carril = Greenfoot.getRandomNumber(3);
            //La variable carril tomará de forma aleatoria el valor de 0, 1 o 2.
            
            if(carril == 0) {
                addObject(new Hoyo(velocidad_carro),185, 100);
                //Se creará un hoyo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Hoyo(velocidad_carro),300, 100);
                //Se creará un hoyo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Hoyo(velocidad_carro),415, 100);
                //Se creará un hoyo con la velocidad del carro en el carril de la derecha.
                }
            
            carril = carril + 1;
            carril = carril % 3;
            /*Al sumarle 1 al valor de carril y luego obtener el residuo que queda de dividir dentro
            de 3, se obtiene un entero diferente del anterior que también está entre 0 y 2.
            Si carril era 0, quedará 1. Si carril era 1, quedará 2. Si carril era 2, quedará 0.*/
            
            if(carril == 0) {
                addObject(new Hoyo(velocidad_carro),185, 100);
                //Se creará un hoyo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Hoyo(velocidad_carro),300, 100);
                //Se creará un hoyo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Hoyo(velocidad_carro),415, 100);
                //Se creará un hoyo con la velocidad del carro en el carril de la derecha.
                }
            
            num_obstaculos = 2;
            
            /*Este método va a permitir generar dos obstáculos en dos carriles diferentes elegidos
            de forma aleatoria.*/
        }
    }
    
    //[Métodos o funciones secundarias]
    public void obstaculo_esquivado()
    {
        contadorEsquives.aumentar();
        num_esquives = num_esquives + 1;
        /*Este método va a permitir sumar 1 a la variable de los
        esquives en la dificultad actual.*/
    }
    
    public void disminuir_num_obstaculos()
    {
        num_obstaculos = num_obstaculos - 1;
        /*Este método va a permitir restar 1 a la variable del número de obstáculos que
        se encuentran activos en la pantalla.*/
    }  
}
