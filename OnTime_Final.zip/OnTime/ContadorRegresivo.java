import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Este será el conteo regresivo antes de iniciar cada partida
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class ContadorRegresivo extends Actor
{
    //[Definición de variables]
    
    public static final GreenfootSound sonido_conteo = new GreenfootSound("Conteo.wav");
    //Esta variable contendrá el efecto de sonido que trendrá cada número de la cuenta regresiva.
    
    public static final GreenfootSound sonido_go = new GreenfootSound("Go.wav");
    //Esta variable contendrá el efecto de sonido que trendrá el "Go!" final de la cuenta regresiva.
    
    private int conteo = 3;
    //Este entero será el valor inicial de la cuenta regresiva. 
    
    //[Constructor]
    public ContadorRegresivo()
    {
        setImage(new GreenfootImage(""+conteo+"", 175, Color.WHITE, null));
        sonido_conteo.play();
    }
    
    //[Método principal]
    public void act()
    {
        if (conteo > 0){
            setImage(new GreenfootImage(""+conteo+"", 175, Color.WHITE, null));
        }
        desaparecer();
    }
    
    //[Métodos más relevantes]
    public void disminuir(){
        conteo = conteo - 1;
        /*Este método va a permitir restar 1 al contador cada vez que se llame.*/
    }
    public int getValue(){
        return conteo;
        /*Este método va a regresar el valor actual del contador.*/
    }
    public void desaparecer(){
        Actor contacto = getOneIntersectingObject(Obstaculo.class);
        if (contacto != null) 
        {
            getWorld().removeObject(this);
        }
        /*Este método hace que, cuando el primer obstáculo llegue a la altura del contador del conteo regresivo, 
        este contador desaparezca de la pantalla.*/
    }
}