import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pantalla que se muestra al ganar
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Ganador extends World
{
    //[[Definición de variables]]
    
    private static final GreenfootSound musica_ganar = new GreenfootSound("Ganar.wav");
    //Esta variable contendrá la música que debe sonar al ganar. 
    
    private Boton boton_menu = new Boton("Boton menu");
    //Esta variable será el botón para regresar al menú. 
    
    //[Constructor]
    public Ganador()
    {    
       //Crear una pantalla para mostrar al perder de 600 x 675 pixeles
       super(600,675,1);
       
       //Reproducir el sonido que debe sonar al ganar.
       musica_ganar.play();
     
       //Posicionar el objeto (botón para regresar al menú) en la pantalla
       addObject(boton_menu, 296, 585);
    }
    
    //[Método principal]
    public void act()
    {
        detenerSonido();
        regresarInicio();
    }
    
    //[Métodos más relevantes]
    public void regresarInicio()
    {
        boolean clickMenu = Greenfoot.mouseClicked(boton_menu);
        if ((Greenfoot.isKeyDown("Space") || Greenfoot.isKeyDown("Enter") || clickMenu==true)) {
            musica_ganar.stop();
            Greenfoot.setWorld(new Inicio());
        }
        /*Este método va a permitir que, al presionar la barra espaciadora, enter o hacer click sobre el botón de menú,
        se detenga el efecto de sonido que se reproduce al ganar y se regrese al jugador a la pantalla de inicio.*/    
    }
    public void detenerSonido()
    {
        Inicio.musica_juego.stop();
        
        /*Este método va a permitir detener la música de fondo del juego.*/
    }
}
