import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Decoración del ambiente. 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ambiente extends Actor
{
    //[Definición de variables]
    
    private String tipo_de_decoracion;
    //Esta variable de tipo String definirá el tipo de decoración que se mostrará y el modo de juego en el que está la decoración.
    
    private int ciclo;
    
    //[Constructor]
    public Ambiente(String decoracion)
    {
        if (decoracion == "arbusto"){
            setImage(new GreenfootImage("Arbusto.png"));
        }
        else{
            setImage(new GreenfootImage("Girasol.png"));
        }
        tipo_de_decoracion = decoracion;
        /*Este método hace que, si al crear un objeto de la clase Ambiente se le da como parámetro "arbusto", este tendrá la
        imagen de un arbusto. Pero si se le da cualquier otro parámetro, tendrá la imagen de un girasol.*/
    }
    
    //[Método principal]
    public void act()
    {
        rotar();
        movimiento();
    }
    
    //[Métodos más relevantes]
    public void rotar()
    {
        if (tipo_de_decoracion == "girasol"){
            turn(1);
        }
        /*Este método hace que, si el objeto de decoración es un girasol, este estará rotando lentamente.*/
    }
    public void movimiento()
    {
        ciclo = ciclo + 1;
        if (ciclo==3){
            setLocation(getX(), getY()+1);
            ciclo = 0;
        }
        if (getY() >= getWorld().getHeight()-15)
        {
            setLocation(getX(), 95);
        }
        /*Este método hace que los objetos de decoración se muevan hacia abajo y, al llegar al límite inferior de la pantalla, estos
        se muevan inmediatamente hacia la parte superior de la pantalla, manteniendo su coordenada en el eje x. */
    }
}
