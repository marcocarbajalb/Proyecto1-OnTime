import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Jugador
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Carro extends Actor
{
    //[Definición de variables]
    
    private int velocidad;
    //Este entero definirá la velocidad a la que se mueve el carro.
    
    private String modo;
    //Esta variable de tipo String definirá en qué mundo ha sido creado ese obstáculo, ya sea en el juego "normal" o en el "infinito". 
    
    //[Constructor]
    public Carro(int v, String modo_de_juego)
    {
        velocidad = v;
        modo = modo_de_juego;
    }
    
    //[Método principal]
    public void act()
    {
        moverse();
        chocar();
    }
    
    //[Métodos más relevantes]
    public void moverse()
    {
        if(Greenfoot.isKeyDown("right")){
            if(getX() < 440)
                setLocation(getX()+velocidad, getY());    
        }
        if(Greenfoot.isKeyDown("left")){
            if (getX() > 160)
                setLocation(getX()-velocidad, getY());     
        }
        if(Greenfoot.isKeyDown("up")){
            if (getY() > 330)
                setLocation(getX(), getY()-velocidad);     
        }
        if(Greenfoot.isKeyDown("down")){
            if (getY() < 575)
                setLocation(getX(), getY()+velocidad);     
        }
        /*Este método permite controlar el movimiento del carro con las flechas del teclado, la
        velocidad determinará la cantidad de pixeles que el carro avanzará al presionar la tecla.*/
    }
    public void chocar()
    {
        /*La variable choque será de tipo actor y su valor será el actor de la clase Obstaculo
        que esté intersecando con el carro.*/
        Actor choque = getOneIntersectingObject(Obstaculo.class);
        if (choque != null) 
        {
            getWorld().removeObject(choque);
            getWorld().removeObject(this);
            if (modo=="normal"){
                int esquives_alcanzados = JuegoNormal.esquives_alcanzados();
                Greenfoot.setWorld(new Perdedor(esquives_alcanzados));}
            else {
                int esquives_alcanzados = JuegoInfinito.esquives_alcanzados();
                Greenfoot.setWorld(new GameOver(esquives_alcanzados));}
        }
        /*Este método hace que, al detectar que el carro está tocando un obstáculo, remueve ambos actores
        del mundo y muestra la pantalla que debe salir al perder (dependiendo de si es el modo normal o infinito).
        Además, le da como parámetro a la pantalla que sale al perder la cantidad de esquives a los que llegó el jugador.*/
    }
    
    //[Métodos o funciones secundarias]
    public void aumentar_velocidad()
    {
        velocidad = velocidad + 1;
        /*Este método permite sumar 1 a la velocidad del carro.*/
    }
}
