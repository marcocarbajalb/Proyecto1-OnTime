import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pantalla que se muestra al perder
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class GameOver extends World
{
    //[[Definición de variables]]
    
    private static final GreenfootSound musica_perder = new GreenfootSound("Perder_infinito.wav");
    //Esta variable contendrá la música que debe sonar al perder en el modo infinito. 
    
    private static Boton boton_menu = new Boton("Boton menu");
    //Esta variable será el botón para regresar al menú. 
    
    private static Contador contadorGameOver = new Contador();
    //Esta variable será el contador que contenga la cantidad de esquives a los que llegó el jugador.
    
    //[Constructor]
    public GameOver(int esquives_alcanzados)
    {    
       //Crear una pantalla para mostrar al perder de 600 x 675 pixeles
       super(600,675,1);
       
       //Reproducir el sonido que debe sonar al perder.
       musica_perder.play();
    
       //Posicionar los objetos (botón para regresar al menú y contador de esquives alcanzados) en la pantalla
       addObject(boton_menu, 296, 585);
       
       /*Se le dará al contador de esquives a los que llegó el jugador la cantidad que fue ingresada como parámetro al crear
       esta clase, y se posicionará este contador en la pantalla.*/
       int esquivesAlcanzados = esquives_alcanzados;
       contadorGameOver.setValue(esquivesAlcanzados);
       addObject(contadorGameOver, 300, 215);
    }
    
    //[Método principal]
    public void act()
    {
        detenerSonido();
        regresarInicio();
    }
    
    //[Métodos más relevantes]
    public void regresarInicio()
    {
        boolean click = Greenfoot.mouseClicked(boton_menu);
        if ((Greenfoot.isKeyDown("Space") || Greenfoot.isKeyDown("Enter") || click==true)) {
            musica_perder.stop();
            Greenfoot.setWorld(new Inicio());
        }
        /*Este método va a permitir que, al presionar la barra espaciadora, enter o hacer click sobre el botón,
        se detenga el efecto de sonido que se reproduce al perder y se regrese al jugador a la pantalla de inicio.*/    
    }
    public void detenerSonido()
    {
        Inicio.musica_juego.stop();
        
        /*Este método va a permitir detener la música de fondo del juego.*/
    }
}
