import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Obstáculos
 * 
 * @author Marco Carbajal y Carlos Aldana 
 * @version Greenfoot 3.7.1
 */
public class Obstaculo extends Actor
{
    //[Definición de variables]
    
    private int velocidad;
    //Este entero definirá la velocidad a la que se mueve el obstáculo.
    
    private String modo;
    //Esta variable de tipo String definirá en qué mundo ha sido creado ese obstáculo, ya sea en el juego "normal" o en el "infinito". 
    
    //[Constructor]
    public Obstaculo(int v, String modo_de_juego)
    {
        velocidad = v;
        modo = modo_de_juego;
        imagen();
    }
    
    //[Método principal]
    public void act()
    {
        movimiento();
        desaparecer();
    }
    
    //[Métodos más relevantes]
    public void imagen()
    {
        int tipo_de_obstaculo = Greenfoot.getRandomNumber(3);
        
        if(tipo_de_obstaculo == 0) {
                setImage(new GreenfootImage("Hoyo.png"));
                //Se le dará al obstáculo la imagen de un hoyo. 
                }
            else if(tipo_de_obstaculo == 1) {
                setImage(new GreenfootImage("Cono.png"));
                //Se le dará al obstáculo la imagen de un cono.
                }
            else {
                setImage(new GreenfootImage("Barrera.png"));
                //Se le dará al obstáculo la imagen de una barrera de tránsito.
                }
        /*Este método hace que aleatoriamente se le asigne una imagen a cada obstáculo
        creado, ya sea la imagen de un hoyo, de un cono, o de una barrera de tránsito.*/
    }
    public void movimiento()
    {
        setLocation(getX(), getY()+velocidad);
        /*Este método hace que el obstáculo se mueva hacia abajo, la velocidad determinará
        la cantidad de pixeles que avanzará el obstáculo al ejectuar el método.*/
    }
    public void desaparecer()
    {
      if (getY() >= getWorld().getHeight()-1)
        {
            if (modo=="normal"){
                JuegoNormal modo_normal = (JuegoNormal) getWorld();
                modo_normal.removeObject(this);
                modo_normal.obstaculo_esquivado();
                modo_normal.disminuir_num_obstaculos();
                Greenfoot.playSound("Esquive_volumen_ajustado.wav");
            }
            else {
                JuegoInfinito modo_infinito = (JuegoInfinito) getWorld();
                modo_infinito.removeObject(this);
                modo_infinito.obstaculo_esquivado();
                modo_infinito.disminuir_num_obstaculos();
                Greenfoot.playSound("Esquive_volumen_ajustado.wav");
            }
        }
      /*Este método hace que, cuando el obstáculo llegue al límite inferior de la pantalla, se remueva
      dicho objeto. Sin embargo, primero verifica de qué modo de juego se trata, para retirar el objeto del mundo
      adecuado (JuegoNormal si es el modo "normal" o JuegoInfinito si es el modo "infinito"). Además, contabiliza
      que el obstáculo fue esquivado y reproduce el sonido de esquive.*/
    }
}