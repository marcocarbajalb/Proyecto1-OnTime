import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Carretera en la que se desarrolla el modo de juego normal
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class JuegoNormal extends World
{
    //[[Definición de variables]]
    
    private static Contador contadorEsquives, contadorDificultad; 
    //contadorEsquives: esta variable de tipo Contador será el contador para los esquives.
    //contadorDificultad:esta variable de tipo Contador será el contador para la dificultad.
    
    private int velocidad_carro, num_esquives, num_obstaculos;
    //velocidad_carro: este entero definirá la velocidad del carro.
    //num_esquives: este entero contendrá el número total de esquives que se han hecho en la dificultad actual.
    //num_obstaculos: este entero contendrá el número de obstáculos que se encuentran activos en la pantalla. 
    
    private final int num_esquives_dificultad = 6;
    //El número de esquives necesarios para aumentar la dificultad es de 6.
    
    private Carro carro;
    //Esta variable de tipo Carro será el carro que controlará el jugador. 
    
    private Ambiente a1, a2, a3, a4, g1, g2, g3, g4, a5, a6, a7, a8, g5, g6, g7, g8;
    //Estas variables de tipo Ambiente serán la decoración de los laterales. 
    
    //[Constructor]
    public JuegoNormal()
    {    
       //Crear un nuevo mundo de 600 x 675 pixeles
       super(600,675,1);
       
       //Establecer que el número total de esquives inicie en 0.
       num_esquives = 0;
       //La velocidad inicial del carro (y, por tanto, de los obstáculos) será de 3.
       velocidad_carro = 3;
       
       //Crear los contadores de esquives y dificultad, así como el carro del jugador y toda la decoración.
       contadorEsquives = new Contador();
       contadorDificultad = new Contador();
       carro = new Carro(velocidad_carro,"normal");
       a1 = new Ambiente("arbusto");
       a2 = new Ambiente("arbusto");
       a3 = new Ambiente("arbusto");
       a4 = new Ambiente("arbusto");
       g1 = new Ambiente("girasol");
       g2 = new Ambiente("girasol");
       g3 = new Ambiente("girasol");
       g4 = new Ambiente("girasol");
       a5 = new Ambiente("arbusto");
       a6 = new Ambiente("arbusto");
       a7 = new Ambiente("arbusto");
       a8 = new Ambiente("arbusto");
       g5 = new Ambiente("girasol");
       g6 = new Ambiente("girasol");
       g7 = new Ambiente("girasol");
       g8 = new Ambiente("girasol");
       
       //La dificultad del juego debe iniciar en 1. 
       contadorDificultad.aumentar();
       
       //Posicionar los objetos (contadores y jugador) en la pantalla
       addObject(carro, 300, 570);
       addObject(contadorDificultad, 515, 40);
       addObject(contadorEsquives, 192, 40);
       
       //Decoración lado izquierdo
       addObject(a1,37,177);
       addObject(g1,71,130);
       addObject(a2,41,322);
       addObject(g2,68, 272);
       addObject(a3,39,476);
       addObject(g3,63,428);
       addObject(a4,46,630);
       addObject(g4,68,575);
       //Decoración lado derecho
       addObject(a5,600-37,177);
       addObject(g5,600-71,130);
       addObject(a6,600-41,322);
       addObject(g6,600-68, 272);
       addObject(a7,600-39,476);
       addObject(g7,600-63,428);
       addObject(a8,600-46,630);
       addObject(g8,600-68,575);
    }
    
    //[Método principal]
    public void act()
    {
        subir_dificultad();
        generador_de_obstaculos();
        ganador();
    }
    
    //[Métodos más relevantes]
    public void subir_dificultad()
    {
        if(num_esquives == num_esquives_dificultad){
            //Aumentar la velocidad del carro
            velocidad_carro = velocidad_carro + 1;
            carro.aumentar_velocidad();
            
            //Aumentar la dificultad
            contadorDificultad.aumentar();
            
            //Resetear la variable del número total de esquives que se han hecho en la dificultad actual
            num_esquives = 0;
        }
        /*Este método va a permitir aumentar la dificultad (que se manifiesta en la velocidad del carro)
        cuando el número de esquives en la dificultad actual llegue a 6.*/
    }
    public void generador_de_obstaculos()
    {
        if(num_obstaculos == 0)
        {
            String continuar;
            int carril = Greenfoot.getRandomNumber(3);
            //La variable carril tomará de forma aleatoria el valor de 0, 1 o 2.
            
            if(carril == 0) {
                addObject(new Obstaculo(velocidad_carro,"normal"),185, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Obstaculo(velocidad_carro,"normal"),300, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Obstaculo(velocidad_carro,"normal"),415, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la derecha.
                }
            
            carril = carril + 1;
            carril = carril % 3;
            /*Al sumarle 1 al valor de carril y luego obtener el residuo que queda de dividir dentro
            de 3, se obtiene un entero diferente del anterior que también está entre 0 y 2.
            Si carril era 0, quedará 1. Si carril era 1, quedará 2. Si carril era 2, quedará 0.*/
            
            if(carril == 0) {
                addObject(new Obstaculo(velocidad_carro,"normal"),185, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la izquierda.
                }
            else if(carril == 1) {
                addObject(new Obstaculo(velocidad_carro,"normal"),300, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril central.
                }
            else {
                addObject(new Obstaculo(velocidad_carro,"normal"),415, 100);
                //Se creará un obstáculo con la velocidad del carro en el carril de la derecha.
                }
            
            num_obstaculos = 2;
            
            /*Este método va a permitir generar dos obstáculos en dos carriles diferentes elegidos
            de forma aleatoria.*/
        }
    }
    public void ganador()
    {
        if (contadorEsquives.getValue() == 30)
        {
        Greenfoot.setWorld(new Ganador());
        }
        /*Este método va a permitir que, al llegar a los 30 esquives, al jugador se le mande
        a la pantalla que se muestra al ganar ("Has llegado a tiempo").*/
    }
        
    //[Métodos o funciones secundarias]
    public void obstaculo_esquivado()
    {
        num_esquives = num_esquives + 1;
        contadorEsquives.aumentar();
        /*Este método va a permitir sumar 1 a la variable de los esquives en la dificultad actual, 
        así como aumentar el contador de esquives en 1 por cada obstáculo esquivado.*/
    }
    public void disminuir_num_obstaculos()
    {
        num_obstaculos = num_obstaculos - 1;
        /*Este método va a permitir restar 1 a la variable del número de obstáculos que
        se encuentran activos en la pantalla.*/
    }
    public static int esquives_alcanzados()
    {
        return contadorEsquives.getValue();
        /*Al llamar este método, se regresará (como entero) el valor actual del contador de los
        esquives en este mundo.*/
    }
}
