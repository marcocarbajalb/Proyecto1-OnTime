import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pantalla de inicio (o menú)
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Inicio extends World
{
    //[[Definición de variables]]
    
    public static final GreenfootSound musica_juego = new GreenfootSound("Musica_fondo.wav");
    //Esta variable contendrá la música que debe sonar de fondo en el juego. 
    
    private static Boton boton_inicio = new Boton("Boton inicio");
    //Esta variable será el botón para iniciar la partida en modo normal. 
    
    private static Boton boton_infinito = new Boton("Boton infinito");
    //Esta variable será el botón para iniciar la partida en modo infinito. 
    
    private static Boton boton_mute_sonido = new Boton("Boton mute/sonido");
    //Esta variable será el botón que servirá ya sea para silenciar o volver a reproducir la música de fondo.
    
    private static Boton boton_salir = new Boton("Boton salir");
    //Esta variable será el botón para salir del juego. 
    
    private static String detener_musica;
    //Esta variable será modificada al pulsar el botón de detener la música, para que el juego ya no intente reproducir la música de fondo.
    
    //[Constructor]
    public Inicio()
    {    
        //Crear una pantalla para el menú de 600 x 675 pixeles
       super(600,675,1);
       
       detener_musica = "No";
       
       //Posicionar los objetos (botón de inicio del modo normal e infinito, así como el de mute y salir) en la pantalla
       addObject(boton_inicio, 195, 577);
       addObject(boton_infinito, 401, 577);
       addObject(boton_mute_sonido, 37, 639);
       addObject(boton_salir, 563, 639);
    }
    
    //[Método principal]
    public void act()
    {
        musica();
        silenciar();
        salir();
        iniciarPartida();
    }
    
    //[Métodos más relevantes]
    public void iniciarPartida()
    {
        boolean clickNormal = Greenfoot.mouseClicked(boton_inicio);
        if (clickNormal==true) {
            Greenfoot.setWorld(new JuegoNormal());
        }
        boolean clickInfinito = Greenfoot.mouseClicked(boton_infinito);
        if (clickInfinito==true) {
            Greenfoot.setWorld(new JuegoInfinito());
        }
        /*Este método va a permitir que, al hacer click sobre el botón de inicio, se inice una nueva partida en modo normal.
        Asimismo, al hacer click sobre el botón de infinito, se iniciará una nueva partida en modo infinito.*/  
    }
    public void musica()
    {
        if (detener_musica=="No"){
        musica_juego.playLoop();
        boton_mute_sonido.setImage(new GreenfootImage("Boton_sonido.png"));
        }
        /*Este método va a permitir que la música de fondo del juego se reproduzca en loop, empezando desde la pantalla de inicio.*/ 
    }
    public void silenciar()
    {
        boolean clickSilencioSonido = Greenfoot.mouseClicked(boton_mute_sonido);
        if (clickSilencioSonido==true && detener_musica=="No") {
            musica_juego.stop();
            boton_mute_sonido.setImage(new GreenfootImage("Boton_mute.png"));
            detener_musica = "Sí";
        }
        else if (clickSilencioSonido==true && detener_musica=="Sí") {
            boton_mute_sonido.setImage(new GreenfootImage("Boton_sonido.png"));
            detener_musica = "No";
        }
        /*Este método va a permitir que, al hacer click sobre el botón de sonido, se detenga la música de fondo. Además, cambiará
        la imagen, dando a entender que si se le da click nuevamente, se volverá a reproducir la música.*/
    }
    public void salir()
    {
        boolean clickSalir = Greenfoot.mouseClicked(boton_salir);
        if (clickSalir==true) {
            musica_juego.stop();
            detener_musica = "Sí";
            boton_mute_sonido.setImage(new GreenfootImage("Boton_mute.png"));
            Greenfoot.stop();
        }
        /*Este método va a permitir que, al hacer click sobre el botón de salir, se detenga el juego por completo
        (junto con la música de fondo).*/
    }
}