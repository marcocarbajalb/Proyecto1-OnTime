import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Botón de inicio o de regresar al menú
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Boton extends Actor
{
    //[Definición de variables]
    
    private String tipo_de_boton;
    //Esta variable de tipo String definirá el tipo de botón que se mostrará. 
    
    //[Constructor]
    public Boton(String tipo_de_boton)
    {
        if (tipo_de_boton == "Boton inicio"){
            setImage(new GreenfootImage("Boton_inicio.png"));
        }
        else if (tipo_de_boton == "Boton infinito") {
            setImage(new GreenfootImage("Boton_infinito.png"));
        }
        else if (tipo_de_boton == "Boton menu"){
            setImage(new GreenfootImage("Boton_menu.png"));
        }
        else if (tipo_de_boton == "Boton mute/sonido"){
            setImage(new GreenfootImage("Boton_sonido.png"));
        }
        else{
            setImage(new GreenfootImage("Boton_salir.png"));
        }
        
        /*Este método hace que, si al crear un botón se le da como parámetro "Boton inicio", este tendrá la
        imagen del boton de inicio del modo normal. Si se le da como parámetro "Boton infinito", este tendrá
        la imagen del boton de inicio del modo infinito. Si se le da como parámetro "Boton menu", este tendrá
        la imagen del boton para regresar al menú. Si se le da como parámetro "Boton mute/sonido", este tendrá
        la imagen del boton para reproducir o silenciar la música de fondo. Pero si se le da cualquier otro parámetro, 
        tendrá la imagen del botón para salir del juego.*/
    }
}
