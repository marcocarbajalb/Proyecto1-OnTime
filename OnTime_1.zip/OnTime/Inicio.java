import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Inicio here.
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Inicio extends World
{

    /**
     * Constructor for objects of class Inicio.
     * 
     */
    public Inicio()
    {    
        //Crear una pantalla para el menu de 600 x 675 pixeles
       super(600,675,1);
       
       Iniciar boton_inicio = new Iniciar();
       addObject(boton_inicio, 300, 550);
    }
    
    public void act()
    {
        if (Greenfoot.isKeyDown("Space") || Greenfoot.isKeyDown("Enter")) {
            Greenfoot.setWorld(new MyWorld());
        }
        /*Este método va a permitir que, al precionar la barra espaciadora o enter, se inicie
        una nueva partida.*/
    }
}
