import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Perdedor here.
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Perdedor extends World
{

    /**
     * Constructor for objects of class Perdedor.
     * 
     */
    public Perdedor()
    {    
       //Crear una pantalla para mostrar al perder de 600 x 675 pixeles
       super(600,675,1);
       
       //Posicionar el objeto (botón para regresar al menú) en la pantalla
       Menu boton_menu = new Menu();
       addObject(boton_menu, 296, 585);
    }
    
    //[Método principal]
    public void act()
    {
        if (Greenfoot.isKeyDown("Space") || Greenfoot.isKeyDown("Enter")) {
            Greenfoot.setWorld(new Inicio());
        }
        /*Este método va a permitir que, al precionar la barra espaciadora o enter, se regrese
        a la pantalla de inicio.*/
    }
}
