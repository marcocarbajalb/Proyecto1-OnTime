import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Jugador
 * 
 * @author Marco Carbajal y Carlos Aldana
 * @version Greenfoot 3.7.1
 */
public class Carro extends Actor
{
    //[Definición de variables]
    
    private int velocidad;
    //Este entero definirá la velocidad a la que se mueve el carro.
    
    //[Constructor]
    public Carro(int v)
    {
        velocidad = v;
    }
    
    //[Método principal]
    public void act()
    {
        moverse();
        chocar();
    }
    
    //[Métodos más relevantes]
    public void moverse()
    {
        if(Greenfoot.isKeyDown("right")){
            if(getX() < 440)
                setLocation(getX()+velocidad, getY());    
        }
        if(Greenfoot.isKeyDown("left")){
            if (getX() > 160)
                setLocation(getX()-velocidad, getY());     
        }
        if(Greenfoot.isKeyDown("up")){
            if (getY() > 330)
                setLocation(getX(), getY()-velocidad);     
        }
        if(Greenfoot.isKeyDown("down")){
            if (getY() < 575)
                setLocation(getX(), getY()+velocidad);     
        }
        /*Este método permite controlar el movimiento del carro con las flechas del teclado, la
        velocidad determinará la cantidad de pixeles que el carro avanzará al presionar la tecla.*/
    }
    
    public void chocar()
    {
        /*La variable choque será de tipo actor y su valor será el actor de la clase Hoyo
        que esté intersecando con el carro.*/
        Actor choque = getOneIntersectingObject(Hoyo.class);
        if (choque != null) 
        {
            getWorld().removeObject(choque);
            getWorld().removeObject(this);
            Greenfoot.setWorld(new Perdedor());;
        }
        /*Este método hace que, al detectar que el carro está tocando un hoyo, remueve ambos actores
        del mundo y detiene el juego.*/
    }
    
    
    //[Métodos o funciones secundarias]
    public void aumentar_velocidad()
    {
        velocidad = velocidad + 1;
        /*Este método permite sumar 1 a la velocidad del carro.*/
    }
}
