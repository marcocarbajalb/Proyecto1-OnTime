import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Obstáculo
 * 
 * @author Marco Carbajal y Carlos Aldana 
 * @version Greenfoot 3.7.1
 */
public class Hoyo extends Actor
{
    //[Definición de variables]
    
    private int velocidad;
    //Este entero definirá la velocidad a la que se mueve el hoyo.
    
    //[Constructor]
    public Hoyo(int v)
    {
        velocidad = v;
    }
    
    //[Método principal]
    public void act()
    {
        movimiento();
        desaparecer();
    }
    
    //[Métodos más relevantes]
    public void movimiento()
    {
        setLocation(getX(), getY()+velocidad);
        /*Este método hace que el hoyo se mueva hacia abajo, la velocidad determinará
        la cantidad de pixeles que avanzará el hoyo al ejectuar el método.*/
    }
    public void desaparecer()
    {
      if (getY() >= getWorld().getHeight()-1)
        {
            MyWorld juego = (MyWorld) getWorld();
            juego.removeObject(this);
            juego.obstaculo_esquivado();
            juego.disminuir_num_obstaculos();
        }
      /*Este método hace que, cuando el hoyo llegue al límite inferior de la pantalla, se remueva
      dicho objeto. Además, contabiliza que el obstáculo fue esquivado.*/
    }
}
